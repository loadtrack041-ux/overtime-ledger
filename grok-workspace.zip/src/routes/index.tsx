import { createFileRoute, getRouteApi, Navigate } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

const rootRoute = getRouteApi("__root__");

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { sessionUser } = rootRoute.useRouteContext();
  const { user } = useCurrentUserState();
  if (user || sessionUser) return <Navigate to="/app" />;
  return <RedirectToSignIn />;
}
