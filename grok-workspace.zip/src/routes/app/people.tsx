import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useActor } from "@/components/actor";
import { EmptyState, PageHeader } from "@/components/empty-state";
import { RoleBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/input";
import { createUser, listDepartments, listUsers } from "@/lib/overtime/server-fns";
import type { Role } from "@/lib/overtime/types";
import { canManageAdmins, canManageUsers } from "@/lib/overtime/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/app/people")({ component: PeoplePage });

const TABS: { id: Role; label: string }[] = [
  { id: "worker", label: "Workers" },
  { id: "supervisor", label: "Supervisors" },
  { id: "admin", label: "Admins" },
];

function PeoplePage() {
  const actor = useActor();
  const [tab, setTab] = useState<Role>(actor.acting.role === "supervisor" ? "worker" : "worker");
  const [creating, setCreating] = useState(false);
  const users = useQuery({ queryKey: ["users", tab], queryFn: () => listUsers({ data: { role: tab } }) });
  const canCreate = canManageUsers(actor.acting.role) && (tab !== "admin" || canManageAdmins(actor.acting.role));

  return (
    <div>
      <PageHeader
        kicker="Directory"
        title="People"
        action={
          canCreate ? (
            <Button size="sm" onClick={() => setCreating(true)}>
              Add {tab}
            </Button>
          ) : null
        }
      />
      {actor.acting.role !== "supervisor" ? (
        <div className="mb-4 grid grid-cols-3 gap-1 rounded-lg bg-surface-2 p-1">
          {TABS.filter((t) => t.id !== "admin" || canManageUsers(actor.acting.role)).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={cn(
                "h-10 rounded-md text-sm font-medium",
                tab === t.id ? "bg-surface text-ink shadow-soft" : "text-muted",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      ) : null}
      <div className="space-y-2">
        {(users.data ?? []).map((u) => (
          <Link
            key={u.userId}
            to="/app/users/$id"
            params={{ id: u.userId }}
            className="flex items-center justify-between rounded-xl border border-line bg-surface px-4 py-3 shadow-soft"
          >
            <div>
              <p className="font-medium">{u.fullName}</p>
              <p className="text-xs text-muted">
                {u.employeeId ?? "No ID"} · {u.departmentName ?? "No dept"} {u.isActive ? "" : "· Deactivated"}
              </p>
            </div>
            <RoleBadge role={u.role} />
          </Link>
        ))}
        {users.data?.length === 0 ? (
          <EmptyState title="No people here" body="Create workers and supervisors so overtime has somewhere to go." />
        ) : null}
      </div>
      {creating ? <CreateUserDialog role={tab} onClose={() => setCreating(false)} /> : null}
    </div>
  );
}

function CreateUserDialog({ role, onClose }: { role: Role; onClose: () => void }) {
  const qc = useQueryClient();
  const depts = useQuery({ queryKey: ["departments"], queryFn: () => listDepartments() });
  const supervisors = useQuery({
    queryKey: ["users", "supervisor"],
    queryFn: () => listUsers({ data: { role: "supervisor" } }),
  });
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("Ledger2026!");
  const [departmentId, setDepartmentId] = useState("");
  const [supervisorUserId, setSupervisorUserId] = useState("");
  const [employeeId, setEmployeeId] = useState("");

  const mutation = useMutation({
    mutationFn: () =>
      createUser({
        data: {
          name,
          email,
          password,
          role,
          departmentId: departmentId || null,
          supervisorUserId: supervisorUserId || null,
          employeeId: employeeId || null,
        },
      }),
    onSuccess: async () => {
      toast.success("Account created");
      await qc.invalidateQueries({ queryKey: ["users"] });
      onClose();
    },
    onError: (err: Error) => toast.error(err.message),
  });

  return (
    <div className="fixed inset-0 z-50 grid place-items-end md:place-items-center">
      <button type="button" className="absolute inset-0 bg-ink/40" aria-label="Close" onClick={onClose} />
      <form
        className="relative z-10 max-h-[90dvh] w-full overflow-y-auto rounded-t-xl border border-line bg-surface p-5 shadow-soft md:max-w-md md:rounded-xl"
        onSubmit={(e) => {
          e.preventDefault();
          mutation.mutate();
        }}
      >
        <h2 className="font-display text-xl font-semibold">New {role.replace("_", " ")}</h2>
        <div className="mt-4 space-y-3">
          <Field label="Full name">
            <Input required value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Email">
            <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Temporary password">
            <Input value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          <Field label="Employee ID" hint="Leave blank to auto-assign">
            <Input value={employeeId} onChange={(e) => setEmployeeId(e.target.value)} />
          </Field>
          <Field label="Department / project">
            <Select value={departmentId} onChange={(e) => setDepartmentId(e.target.value)}>
              <option value="">None</option>
              {(depts.data ?? []).map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </Field>
          {role === "worker" ? (
            <Field label="Supervisor">
              <Select required value={supervisorUserId} onChange={(e) => setSupervisorUserId(e.target.value)}>
                <option value="">Select supervisor</option>
                {(supervisors.data ?? []).map((s) => (
                  <option key={s.userId} value={s.userId}>
                    {s.fullName}
                  </option>
                ))}
              </Select>
            </Field>
          ) : null}
          <Button type="submit" size="lg" className="w-full" disabled={mutation.isPending}>
            {mutation.isPending ? "Creating…" : "Create account"}
          </Button>
        </div>
      </form>
    </div>
  );
}
