import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { DEMO_PASSWORD } from "@/lib/overtime/demo";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user } = useCurrentUserState();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [showDemo, setShowDemo] = useState(false);

  if (user) return <Navigate to="/app" />;

  async function onEmailLogin(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    const { error } = await authClient.signIn.email({ email, password, callbackURL: "/app" });
    setBusy(false);
    if (error) {
      toast.error(error.message ?? "Could not sign in");
      return;
    }
    window.location.href = "/app";
  }

  return (
    <main className="ledger-bg min-h-dvh px-4 py-10">
      <div className="mx-auto flex min-h-[80dvh] max-w-md flex-col justify-center">
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">Northline · Workforce</p>
        <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">Overtime Ledger</h1>
        <p className="mt-2 max-w-sm text-muted">
          Log extra hours from the floor. Supervisors sign on the phone. Payroll exports in one tap.
        </p>

        <form onSubmit={onEmailLogin} className="mt-8 space-y-3 rounded-xl border border-line bg-surface p-5 shadow-soft">
          <Field label="Work email">
            <Input
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
            />
          </Field>
          <Field label="Password">
            <Input
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </Field>
          <Button type="submit" size="xl" className="w-full" disabled={busy || !authEnabled}>
            {busy ? "Signing in…" : "Sign in"}
          </Button>
          <a href="/forgot-password" className="block text-center text-sm text-muted underline-offset-4 hover:underline">
            Forgot password
          </a>
        </form>

        {authEnabled ? (
          <div className="mt-4 space-y-2">
            <p className="text-center text-xs uppercase tracking-[0.16em] text-faint">or</p>
            {GROK_PROVIDERS.map((p) => (
              <Button
                key={p.providerId}
                type="button"
                variant="secondary"
                size="lg"
                className="w-full"
                onClick={() => signIn(p.providerId, { callbackURL: "/app" })}
              >
                Continue with {p.label}
              </Button>
            ))}
          </div>
        ) : (
          <p className="mt-4 text-sm text-muted">Sign-in is disabled.</p>
        )}

        <button
          type="button"
          className="mt-6 text-left text-sm text-muted underline-offset-4 hover:underline"
          onClick={() => setShowDemo((v) => !v)}
        >
          {showDemo ? "Hide demo accounts" : "Demo accounts"}
        </button>
        {showDemo ? (
          <div className="mt-2 rounded-lg border border-line bg-surface p-4 text-sm">
            <p className="text-muted">
              The first person to sign in becomes Super Admin. Sample company users (password{" "}
              <span className="font-mono text-ink">{DEMO_PASSWORD}</span>):
            </p>
            <ul className="mt-2 space-y-1 font-mono text-xs">
              <li>Admin · maria.chen@northline.demo</li>
              <li>Supervisor · james.okonkwo@northline.demo</li>
              <li>Worker · luis.ferreira@northline.demo</li>
            </ul>
            <p className="mt-2 text-muted">
              Super Admins can also use Home → Try a demo role without signing out.
            </p>
          </div>
        ) : null}
      </div>
    </main>
  );
}
