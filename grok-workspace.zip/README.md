# Overtime Ledger

Mobile-first overtime for teams of about 30–300 people. Workers submit extra hours from a phone. Supervisors approve with a signature. Admins export one Excel file for payroll.

## Stack

- **TanStack Start + React 19** — one TypeScript app for UI and server functions
- **Postgres** (Neon in production, embedded PGLite in preview)
- **Better Auth** — Google, X, and email/password. Passwords are hashed. Roles live in `profiles`, not the identity table
- **Tailwind v4** — large tap targets, ledger-paper visual system

Chosen because it deploys as a single web app, needs no native clients, and scales from a small warehouse to a few hundred workers without a separate backend.

## Roles

| Role | Access |
|---|---|
| Super Admin | Everything, including admins, settings, audit, Excel |
| Admin | People, records, reports, Excel — cannot manage Super Admins |
| Supervisor | Assigned workers only, approve/reject with signature |
| Worker | Own overtime only |

Permissions are enforced in every server function, not only in the UI.

## Local development

1. Node 22
2. `npm install`
3. Auth is on when `VITE_AUTH_ENABLED` is not `"false"`
4. `npm run dev` — app listens on port 8080
5. First sign-in becomes Super Admin and loads the Northline sample company

No `.env` file is required in this environment. Production injects `DATABASE_URL` and auth credentials.

## Database

Schema lives in `migrations/`:

- `0001_auth.sql` — Better Auth identity tables
- `0002_overtime.sql` — departments, profiles, overtime, audit, settings

Migrations apply on preview startup and during `npm run build` (production).

## Environment

| Variable | Where | Purpose |
|---|---|---|
| `DATABASE_URL` | server | Neon Postgres (omit locally to use PGLite) |
| `BETTER_AUTH_SECRET` | server | Session signing (injected on deploy) |
| `BETTER_AUTH_URL` | server | Public origin |
| `GROK_AUTH_*` | server | Federated Google/X sign-in |
| `VITE_AUTH_ENABLED` | build | Must not be `"false"` for real accounts |

## Production

Deploy the web app with HTTPS on your domain. Point DNS at the host, enable TLS, and keep `BETTER_AUTH_URL` equal to the public URL.

### Backups

Neon (or your Postgres host) should have daily automated backups. For a self-hosted database:

```
pg_dump "$DATABASE_URL" -Fc -f overtime-$(date +%F).dump
```

Restore with `pg_restore`. Do not delete overtime or user rows — deactivate instead.

### Maintenance

- Deactivate leavers; do not hard-delete if they have overtime history
- Reset passwords from People → user
- Watch Audit log for exports, approvals, and impersonation
- Re-seed is idempotent and only fills missing demo IDs

## Demo accounts

Password for sample users: `Ledger2026!`

- Admin: `maria.chen@northline.demo`
- Supervisor: `james.okonkwo@northline.demo`
- Worker: `luis.ferreira@northline.demo`

The first real sign-in is Super Admin. Use **Try a demo role** on Home to walk the worker and supervisor flows without signing out.
